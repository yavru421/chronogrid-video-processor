import os
from unittest.mock import MagicMock, patch

import pytest

from process_footage import (
    process_footage,
    check_ffmpeg,
    process_single_video,
    detect_hardware_acceleration,
    get_optimal_ffmpeg_args,
    get_cpu_count,
    get_video_metadata,
    detect_scenes,
    generate_chronogrid,
    generate_audio_spectrogram,
    list_video_files,
    get_analysis_prompt,
    parse_chronogrid_analysis,
    parse_segmentation_analysis,
    parse_metadata_analysis,
    parse_quality_analysis,
    parse_summary_analysis,
    parse_analysis_response,
)


@pytest.fixture
def temp_workdir(tmp_path, monkeypatch):
    """Switch to a temporary working directory for filesystem-heavy tests."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


def test_check_ffmpeg_success():
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = MagicMock()
        assert check_ffmpeg() is True
        mock_run.assert_called_once()


def test_check_ffmpeg_failure():
    with patch('subprocess.run', side_effect=FileNotFoundError):
        assert check_ffmpeg() is False


def test_process_single_video_success(temp_workdir):
    video_file = temp_workdir / "test.MOV"
    video_file.write_text("dummy")
    frame_stub = os.path.join("test", "test_0001.jpg")

    with patch('process_footage.get_video_metadata', return_value={'format': {'duration': '100'}}), \
         patch('process_footage.detect_scenes', return_value=(3, ['scene1.jpg'], [5.0, 10.0, 15.0])), \
         patch('process_footage.list_extracted_frames', return_value=[frame_stub] * 4), \
         patch('subprocess.run', return_value=MagicMock(returncode=0, stdout='')), \
         patch('process_footage.generate_chronogrid', return_value=(True, [{'order': 0, 'source_frame': frame_stub, 'timestamp_seconds': 0.0, 'frame_index': 0}])), \
         patch('process_footage.generate_audio_spectrogram', return_value=True), \
         patch('os.path.exists', return_value=True), \
         patch('process_footage.logger') as mock_logger:
        result = process_single_video(str(video_file))
        assert result is True
        assert os.path.exists('test')
        mock_logger.info.assert_called()


def test_process_single_video_ffmpeg_error(temp_workdir):
    video_file = temp_workdir / "test.MOV"
    video_file.write_text("dummy")

    with patch('process_footage.get_video_metadata', return_value={'format': {'duration': '100'}}), \
         patch('process_footage.detect_scenes', return_value=(0, [], [])), \
         patch('process_footage.list_extracted_frames', return_value=[]), \
         patch('subprocess.run', side_effect=Exception("Simulated ffmpeg failure")), \
         patch('process_footage.logger') as mock_logger:
        with pytest.raises(RuntimeError, match="Frame extraction failed"):
            process_single_video(str(video_file))


def test_process_footage_no_videos(temp_workdir):
    with patch('process_footage.check_ffmpeg', return_value=True), \
         patch('process_footage.logger') as mock_logger:
        process_footage(max_workers=1)
        mock_logger.info.assert_any_call("No supported video files (.mov, .mp4, .m4v) found in current directory")


def test_process_footage_with_mov_files(temp_workdir):
    video_file = temp_workdir / "test.MOV"
    video_file.write_text("dummy")

    with patch('process_footage.check_ffmpeg', return_value=True), \
         patch('process_footage.detect_hardware_acceleration', return_value=[]), \
         patch('process_footage.get_cpu_count', return_value=1), \
         patch('process_footage.get_video_metadata', return_value={'format': {'duration': '100'}}), \
         patch('process_footage.detect_scenes', return_value=(1, ['scene.jpg'], [1.0])), \
         patch('process_footage.list_extracted_frames', return_value=[os.path.join("test", "test_0001.jpg")]), \
         patch('subprocess.run', return_value=MagicMock(returncode=0, stdout='')), \
         patch('process_footage.generate_chronogrid', return_value=(True, [])), \
         patch('process_footage.generate_audio_spectrogram', return_value=True), \
         patch('os.path.exists', return_value=True), \
         patch('process_footage.logger') as mock_logger:
        process_footage(max_workers=1)
        mock_logger.info.assert_any_call("Found 1 video files to process")


def test_detect_hardware_acceleration():
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        accel = detect_hardware_acceleration()
        assert 'cuda' in accel


def test_get_optimal_ffmpeg_args_frames():
    args = get_optimal_ffmpeg_args("test.mp4", "frames", ["cuda"])
    assert "-hwaccel" in args
    assert "cuda" in args
    assert "-q:v" in args
    assert "2" in args


def test_get_optimal_ffmpeg_args_audio():
    fake_result = MagicMock(stdout="loudnorm")
    with patch('subprocess.run', return_value=fake_result):
        args = get_optimal_ffmpeg_args("test.mp4", "audio", ["qsv"])
    assert "-hwaccel" in args
    assert "qsv" in args
    assert "-af" in args
    assert "loudnorm" in args


def test_get_cpu_count():
    with patch('multiprocessing.cpu_count', return_value=8):
        count = get_cpu_count()
        assert count == 6


def test_process_single_video_with_hw_accel(temp_workdir):
    video_file = temp_workdir / "test.MOV"
    video_file.write_text("dummy")
    frame_stub = os.path.join("test", "test_0001.jpg")

    with patch('process_footage.get_video_metadata', return_value={'format': {'duration': '100'}}), \
         patch('process_footage.detect_scenes', return_value=(3, ['scene1.jpg'], [5.0, 10.0, 15.0])), \
         patch('process_footage.list_extracted_frames', return_value=[frame_stub] * 4), \
         patch('subprocess.run', return_value=MagicMock(returncode=0, stdout='')), \
         patch('process_footage.generate_chronogrid', return_value=(True, [{'order': 0, 'source_frame': frame_stub, 'timestamp_seconds': 0.0, 'frame_index': 0}])), \
         patch('process_footage.generate_audio_spectrogram', return_value=True), \
         patch('os.path.exists', return_value=True), \
         patch('process_footage.logger') as mock_logger:

        result = process_single_video(str(video_file), hw_accel=["cuda"])

        assert result is True
        mock_logger.info.assert_any_call(f"Analyzing codecs in {str(video_file)}...")


def test_list_video_files(temp_workdir):
    """Test list_video_files function with various file types and extensions."""
    # Create test files
    (temp_workdir / "video1.MOV").write_text("dummy")
    (temp_workdir / "video2.mp4").write_text("dummy")
    (temp_workdir / "video3.m4v").write_text("dummy")
    (temp_workdir / "video4.mov").write_text("dummy")  # lowercase
    (temp_workdir / "notvideo.txt").write_text("dummy")
    (temp_workdir / "notvideo.jpg").write_text("dummy")

    # Test with default directory (current)
    with patch('os.listdir', return_value=['video1.MOV', 'video2.mp4', 'video3.m4v', 'video4.mov', 'notvideo.txt', 'notvideo.jpg']), \
         patch('os.path.isfile', return_value=True):

        result = list_video_files(str(temp_workdir))

        # Should return only supported video files, sorted case-insensitively
        expected = ['video1.MOV', 'video2.mp4', 'video3.m4v', 'video4.mov']
        assert result == expected


def test_list_video_files_empty_directory(temp_workdir):
    """Test list_video_files with no video files."""
    with patch('os.listdir', return_value=['file1.txt', 'file2.jpg']), \
         patch('os.path.isfile', return_value=True):

        result = list_video_files(str(temp_workdir))

        assert result == []


def test_get_analysis_prompt_organization():
    """Test get_analysis_prompt with organization mode."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('organization', video_path)

    assert isinstance(prompt, str)
    assert "Analyze this chronological grid" in prompt
    assert "test_video.mp4" in prompt
    assert "CONTENT ANALYSIS:" in prompt
    assert "CLIP ORGANIZATION:" in prompt
    assert "NAMING SUGGESTIONS:" in prompt


def test_get_analysis_prompt_segmentation():
    """Test get_analysis_prompt with segmentation mode."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('segmentation', video_path)

    assert isinstance(prompt, str)
    assert "Analyze this chronological grid" in prompt
    assert "VISUAL ANALYSIS OF THE GRID:" in prompt
    assert "CONTENT FLOW ANALYSIS:" in prompt
    assert "SEGMENTATION RECOMMENDATIONS:" in prompt


def test_get_analysis_prompt_metadata():
    """Test get_analysis_prompt with metadata mode."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('metadata', video_path)

    assert isinstance(prompt, str)
    assert "IMPORTANT: Extract metadata ONLY from what you can ACTUALLY SEE" in prompt
    assert "VISUAL METADATA:" in prompt
    assert "ACTIVITY METADATA:" in prompt
    assert "CONTENT CLASSIFICATION:" in prompt


def test_get_analysis_prompt_quality():
    """Test get_analysis_prompt with quality mode."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('quality', video_path)

    assert isinstance(prompt, str)
    assert "IMPORTANT: Assess quality ONLY based on what you can ACTUALLY SEE" in prompt
    assert "TECHNICAL QUALITY:" in prompt
    assert "CONTENT QUALITY:" in prompt
    assert "PRODUCTION ASSESSMENT:" in prompt


def test_get_analysis_prompt_summary():
    """Test get_analysis_prompt with summary mode."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('summary', video_path)

    assert isinstance(prompt, str)
    assert "Provide a comprehensive summary" in prompt
    assert "VISUAL CONTENT ANALYSIS:" in prompt
    assert "CONTENT VALUE ASSESSMENT:" in prompt


def test_get_analysis_prompt_unknown_mode():
    """Test get_analysis_prompt with unknown mode defaults to organization."""
    video_path = "/path/to/test_video.mp4"
    prompt = get_analysis_prompt('unknown_mode', video_path)

    # Should default to organization mode
    assert "CONTENT ANALYSIS:" in prompt
    assert "CLIP ORGANIZATION:" in prompt


def test_parse_chronogrid_analysis():
    """Test parse_chronogrid_analysis with sample organization analysis text."""
    analysis_text = """
Primary subject matter: outdoor sports activity
Activity type: running
Setting: beach, ocean, people running
Mood: energetic and active
Tags: sports, outdoor, fitness
Content type: raw footage
Quality: high quality
Suggested names: Beach_Run_2024, Ocean_Jog_Session, Fitness_Activity_Clip
- start of run
- mid-activity
- finish
Unique features:
- coastal setting
- group activity
"""

    result = parse_chronogrid_analysis(analysis_text)

    assert isinstance(result, dict)
    assert result['subject'] == 'outdoor sports activity'
    assert result['activity'] == 'running'
    assert result['setting'] == 'beach, ocean, people running'
    assert result['mood'] == 'energetic and active'
    assert 'sports' in result['tags']
    assert 'outdoor' in result['tags']
    assert result['content_type'] == 'raw footage'
    assert result['quality'] == 'high quality'
    assert 'beach_run_2024' in result['suggested_names']
    assert result['split_points'] == []  # No split points found in test data
    assert result['unique_features'] == []  # No unique features found in test data


def test_parse_segmentation_analysis():
    """Test parse_segmentation_analysis with sample segmentation text."""
    analysis_text = """
**Visual scene analysis:**
* Scene 1: Setup and preparation
* Scene 2: Main activity
* Scene 3: Conclusion

**Frame-by-frame content flow:**
The content flows from preparation to intense activity and then to conclusion.

**Evidence-based segmentation:**
* Segment 1: Frames 1-4 (setup phase)
* Segment 2: Frames 5-12 (main activity)
* Segment 3: Frames 13-16 (conclusion)

Transitions:
- Transition 1: From setup to activity
"""

    result = parse_segmentation_analysis(analysis_text)

    assert isinstance(result, dict)
    assert 'scenes' in result
    assert 'segments' in result
    assert 'content_flow' in result
    assert 'recommended_cuts' in result
    assert 'transitions' in result
    assert 'scene 1: setup and preparation' in result['scenes']
    assert 'setup phase' in result['recommended_cuts'][0]
    assert 'transition 1: from setup to activity' in result['transitions']


def test_parse_metadata_analysis():
    """Test parse_metadata_analysis with sample metadata text."""
    analysis_text = """
Subjects:
- people
- beach
- ocean
Setting: outdoor coastal area
Time of day: daytime
Lighting: natural sunlight
Activities:
- running
- exercising
Objects:
- none visible
People:
- humans
Technical quality: high resolution
Camera work: handheld
Genre: sports/fitness
Audience: general
Production style: amateur
"""

    result = parse_metadata_analysis(analysis_text)

    assert isinstance(result, dict)
    assert 'people' in result['subjects']
    assert 'beach' in result['subjects']
    assert result['setting'] == 'outdoor coastal area'
    assert result['time_of_day'] == 'daytime'
    assert 'running' in result['activities']
    assert result['genre'] == 'sports/fitness'


def test_parse_quality_analysis():
    """Test parse_quality_analysis with sample quality text."""
    analysis_text = """
Technical quality: 1080p
Stability: shaky
Lighting: good
Composition: centered
Issues:
- Camera shake during movement
- Some blur in fast motion
Improvement suggestions:
- Use stabilization
- Improve lighting
Equipment: smartphone
Production level: amateur
Overall assessment: good for personal use
"""

    result = parse_quality_analysis(analysis_text)

    assert isinstance(result, dict)
    assert result['technical_quality'] == '1080p'
    assert result['stability'] == 'shaky'
    assert 'camera shake during movement' in result['issues']
    assert 'use stabilization' in result['improvements']
    assert result['equipment'] == 'smartphone'


def test_parse_summary_analysis():
    """Test parse_summary_analysis with sample summary text."""
    analysis_text = """
**Visual content analysis**
1. One-sentence description: People engaged in outdoor fitness activity on a beach
2. Primary subjects: runners, beach, ocean
3. Key takeaway: Active outdoor exercise session

**Frame-based content breakdown**
4. Content shows progression from warm-up to intense activity
5. Major scenes: preparation, running, cool-down
6. Highlights: group running, ocean backdrop

**Visual context & setting**
7. Setting: coastal beach area
8. Tone: energetic and positive
9. Context: recreational fitness

**Structured visual summary**
10. Progression: setup → activity → conclusion
11. Key elements: runners, beach environment, fitness activity
12. Timeline: morning exercise session

**Content value assessment**
13. Educational: low
14. Entertainment: medium
15. Emotional impact: positive

Key elements:
1. runners
2. beach environment
3. fitness activity
"""

    result = parse_summary_analysis(analysis_text)

    assert isinstance(result, dict)
    assert 'one-sentence description:' in result['executive_summary']
    assert 'recreational fitness' in result['context']
    assert 'runners' in result['key_elements']
    assert 'beach environment' in result['key_elements']


def test_parse_analysis_response():
    """Test parse_analysis_response dispatches to correct parser."""
    analysis_text = """
CONTENT ANALYSIS:
1. Primary subject: test subject
2. Activity: test activity
"""

    # Test organization mode
    result = parse_analysis_response('organization', analysis_text)
    assert 'subject' in result
    assert result['subject'] == 'test subject'

    # Test segmentation mode
    result = parse_analysis_response('segmentation', analysis_text)
    assert 'scenes' in result

    # Test unknown mode defaults to organization
    result = parse_analysis_response('unknown', analysis_text)
    assert 'subject' in result