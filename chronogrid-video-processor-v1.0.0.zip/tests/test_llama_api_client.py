import tempfile
import os
import json
from unittest import mock

import pytest

from llama_api_client import LlamaApiClient


class DummyResponse:
    def __init__(self, status_code=200, json_data=None, iter_lines_data=None):
        self.status_code = status_code
        self._json = json_data or {}
        self._iter_lines_data = iter_lines_data or []
        self.text = json.dumps(self._json) if self._json else ""

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

    def json(self):
        return self._json

    def iter_lines(self, decode_unicode=False):
        for item in self._iter_lines_data:
            if isinstance(item, bytes) and decode_unicode:
                yield item.decode("utf-8")
            else:
                yield item

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def mock_post_non_stream(self, url, *args, **kwargs):
    if url.endswith('/chat/completions'):
        return DummyResponse(json_data={"id": "r1", "model": "fake", "completion_message": {"role": "assistant", "content": "ok"}})
    if url.endswith('/upload-image'):
        return DummyResponse(json_data={"id": "u1", "result": "ok"})
    return DummyResponse(json_data={})


def mock_post_stream(self, url, *args, **kwargs):
    lines = [b"data: {\"delta\":{\"content\":\"Hello\"}}\n", b"data: {\"delta\":{\"content\":\" World\"}}\n", b"event: done\n"]
    return DummyResponse(iter_lines_data=lines)


def test_create_chat_completion_non_stream(monkeypatch):
    monkeypatch.setattr('requests.Session.post', mock_post_non_stream)
    client = LlamaApiClient(bearer_token='t')
    res = client.create_chat_completion({"model": "m", "messages": [{"role": "user", "content": "hi"}]})
    assert res['id'] == 'r1'


def test_stream_chat_completion(monkeypatch):
    monkeypatch.setattr('requests.Session.post', mock_post_stream)
    client = LlamaApiClient(bearer_token='t')
    parts = list(client.stream_chat_completion({"model": "m", "messages": [{"role": "user", "content": "hi"}], "stream": True}))
    assert any('delta' in p for p in parts)


def test_upload_image_and_ask_deprecated():
    client = LlamaApiClient(bearer_token='t')
    with pytest.raises(NotImplementedError, match="upload_image_and_ask is not supported"):
        client.upload_image_and_ask("nonexistent.jpg", "q", "m")
