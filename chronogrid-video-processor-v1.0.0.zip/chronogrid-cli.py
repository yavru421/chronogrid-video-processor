#!/usr/bin/env python3
"""
Chronogrid Video Processor - Industry-Ready CLI/GUI Tool

A comprehensive video processing tool for generating chronogrids and AI analysis.
Supports batch processing, GUI interface, API integration, and plugin extensibility.
"""

import argparse
import sys
from pathlib import Path
from typing import Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    import yaml
except ImportError as e:
    print(f"Error: Required library missing: {e}. Install with: pip install -r requirements.txt")
    raise  # Re-raise instead of exiting

# Import existing modules
from process_footage import process_video, ensure_ffmpeg, iter_video_files, analyze_chronogrid
from llama_api_client import LlamaAPIClient

console = Console()

def print_banner():
    """Print the chronogrid banner."""
    banner = Text("""
 ██████╗██╗  ██╗██████╗  ██████╗ ███╗   ██╗ ██████╗ ██████╗ ██╗██████╗
██╔════╝██║  ██║██╔══██╗██╔═══██╗████╗  ██║██╔════╝ ██╔══██╗██║██╔══██╗
██║     ███████║██████╔╝██║   ██║██╔██╗ ██║██║  ███╗██████╔╝██║██║  ██║
██║     ██╔══██║██╔══██╗██║   ██║██║╚██╗██║██║   ██║██╔══██╗██║██║  ██║
╚██████╗██║  ██║██║  ██║╚██████╔╝██║ ╚████║╚██████╔╝██║  ██║██║██████╔╝
 ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚═╝╚═════╝

Video Processor - Chronogrid & AI Analysis Tool
""", style="bold cyan")
    console.print(Panel(banner, title="Chronogrid CLI", border_style="blue"))

def setup_logging(log_file: Optional[str] = None):
    """Setup logging configuration."""
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file) if log_file else logging.NullHandler()
        ]
    )

def cmd_process(args):
    """Handle the 'process' subcommand."""
    console.print("[bold green]Processing videos...[/bold green]")

    # Ensure ffmpeg
    try:
        ensure_ffmpeg()
    except RuntimeError as e:
        console.print(f"[red]Error: {e}[/red]")
        return 1

    videos = list(iter_video_files(args.inputs or ['.']))
    if not videos:
        console.print("[yellow]No video files found.[/yellow]")
        return 0

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
        task = progress.add_task("Processing videos...", total=len(videos))

        for video in videos:
            try:
                result = process_video(
                    video,
                    frame_step=args.frame_step,
                    grid_size=args.grid_size,
                    prompt=args.prompt if args.analyze else None,
                    cleanup=getattr(args, "cleanup", False)
                )
                console.print(f"[green]✓ Processed {video.name}[/green]")
                progress.advance(task)
            except Exception as e:
                console.print(f"[red]✗ Failed {video.name}: {e}[/red]")
                progress.advance(task)

    return 0

def cmd_analyze(args):
    """Handle the 'analyze' subcommand."""
    console.print("[bold green]Running AI analysis...[/bold green]")

    # Find chronogrids
    chronogrids = []
    for input_path in args.inputs or ['.']:
        path = Path(input_path)
        if path.is_file() and path.suffix.lower() in ['.jpg', '.png'] and 'chronogrid' in path.name:
            chronogrids.append(path)
        elif path.is_dir():
            for file in path.rglob('*'):
                if file.is_file() and file.suffix.lower() in ['.jpg', '.png'] and 'chronogrid' in file.name:
                    chronogrids.append(file)

    if not chronogrids:
        console.print("[yellow]No chronogrid images found.[/yellow]")
        return 0

    # Default prompts for modes
    prompts = {
        'summary': "You are analyzing a 4x4 chronogrid of 16 frames extracted from a video. Describe ONLY what is visually present. Identify the primary subject(s), their actions, tools, animals, and notable objects. Mention the environment, lighting, and any progression or sequence that can be inferred from frame order. Avoid speculation, metaphors, or emotional interpretation—stick to concrete facts. End with a concise timeline-style bullet list summarizing the sequence in order.",
        'segmentation': "Analyze this chronogrid and identify distinct segments or scenes. Describe what changes between frames and where natural scene breaks occur.",
        'metadata': "Extract metadata from this chronogrid: time of day, location indicators, weather conditions, lighting quality, and any text or signage visible.",
        'quality': "Assess the video quality in this chronogrid: resolution, stability, focus, lighting, and any artifacts or issues."
    }

    prompt = prompts.get(args.mode, prompts['summary'])

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
        task = progress.add_task(f"Analyzing {len(chronogrids)} chronogrids...", total=len(chronogrids))

        for chronogrid in chronogrids:
            try:
                analysis = analyze_chronogrid(chronogrid, prompt)
                # Save analysis
                analysis_file = chronogrid.parent / f"{chronogrid.stem}_{args.mode}_analysis.txt"
                analysis_file.write_text(analysis)
                console.print(f"[green]✓ Analyzed {chronogrid.name}[/green]")
                progress.advance(task)
            except Exception as e:
                console.print(f"[red]✗ Failed {chronogrid.name}: {e}[/red]")
                progress.advance(task)

    return 0

def cmd_export(args):
    """Handle the 'export' subcommand."""
    console.print("[bold green]Exporting results...[/bold green]")

    # Find analysis files
    analysis_files = []
    for input_path in args.inputs or ['.']:
        path = Path(input_path)
        if path.is_file() and '_analysis.' in path.name:
            analysis_files.append(path)
        elif path.is_dir():
            for file in path.rglob('*'):
                if file.is_file() and '_analysis.' in file.name:
                    analysis_files.append(file)

    if not analysis_files:
        console.print("[yellow]No analysis files found.[/yellow]")
        return 0

    # Export logic (placeholder for now)
    console.print(f"[green]Found {len(analysis_files)} analysis files to export in {args.format} format.[/green]")
    # TODO: Implement actual export to JSON/CSV/XML
    console.print("[yellow]Export implementation coming soon![/yellow]")
    return 0

def cmd_gui(args):
    """Handle the 'gui' subcommand."""
    console.print("[bold green]Launching GUI...[/bold green]")
    try:
        import subprocess
        subprocess.run([sys.executable, 'chronogrid_gui.py'])
    except FileNotFoundError:
        console.print("[red]GUI script not found. Please ensure chronogrid_gui.py exists.[/red]")
        return 1
    return 0

def cmd_config(args):
    """Handle the 'config' subcommand."""
    console.print("[bold green]Managing configuration...[/bold green]")

    config_file = Path('config.yaml')

    if args.list:
        if config_file.exists():
            try:
                with open(config_file) as f:
                    config = yaml.safe_load(f)
                console.print("[green]Current configuration:[/green]")
                console.print_json(data=config)
            except Exception as e:
                console.print(f"[red]Error reading config: {e}[/red]")
        else:
            console.print("[yellow]No config file found. Create one with --create[/yellow]")
    elif args.create:
        # Placeholder for creating new preset
        console.print(f"[yellow]Create preset '{args.create}' - feature coming soon![/yellow]")
    else:
        console.print("[yellow]Use --list to view config or --create <name> to create preset[/yellow]")

    return 0

def cmd_plugin(args):
    """Handle the 'plugin' subcommand."""
    console.print("[bold green]Managing plugins...[/bold green]")

    plugin_dir = Path('plugins')

    if args.list:
        if plugin_dir.exists():
            plugins = list(plugin_dir.glob('*.py'))
            if plugins:
                table = Table(title="Installed Plugins")
                table.add_column("Name", style="cyan")
                table.add_column("Path", style="magenta")
                for plugin in plugins:
                    table.add_row(plugin.stem, str(plugin))
                console.print(table)
            else:
                console.print("[yellow]No plugins found in plugins/ directory[/yellow]")
        else:
            console.print("[yellow]No plugins/ directory found[/yellow]")
    elif args.install:
        console.print(f"[yellow]Install plugin '{args.install}' - feature coming soon![/yellow]")
    else:
        console.print("[yellow]Use --list to view plugins or --install <path> to install[/yellow]")

    return 0

def main():
    print_banner()

    parser = argparse.ArgumentParser(
        description="Chronogrid Video Processor - CLI/GUI Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  chronogrid-cli process video.mp4 --frame-step 30
  chronogrid-cli analyze video.mp4 --mode summary
  chronogrid-cli gui
  chronogrid-cli config --list
        """
    )

    parser.add_argument('--log', help='Log file path')
    parser.add_argument('--config', help='Configuration file path')

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Process subcommand
    process_parser = subparsers.add_parser('process', help='Batch process videos into chronogrids')
    process_parser.add_argument('inputs', nargs='*', help='Video files or directories')
    process_parser.add_argument('--frame-step', type=int, default=30, help='Extract every Nth frame')
    process_parser.add_argument('--grid-size', type=int, default=4, help='Grid size (NxN)')
    process_parser.add_argument('--analyze', action='store_true', help='Run AI analysis')
    process_parser.add_argument('--prompt', help='Custom analysis prompt')
    process_parser.add_argument('--cleanup', action='store_true', help='Delete intermediate files after analysis')
    process_parser.set_defaults(func=cmd_process)

    # Analyze subcommand
    analyze_parser = subparsers.add_parser('analyze', help='Run AI analysis on chronogrids')
    analyze_parser.add_argument('inputs', nargs='*', help='Video files or chronogrids')
    analyze_parser.add_argument('--mode', choices=['summary', 'segmentation', 'metadata', 'quality'], default='summary', help='Analysis mode')
    analyze_parser.set_defaults(func=cmd_analyze)

    # Export subcommand
    export_parser = subparsers.add_parser('export', help='Export results in various formats')
    export_parser.add_argument('inputs', nargs='*', help='Input files')
    export_parser.add_argument('--format', choices=['json', 'csv', 'xml'], default='json', help='Export format')
    export_parser.set_defaults(func=cmd_export)

    # GUI subcommand
    gui_parser = subparsers.add_parser('gui', help='Launch the graphical user interface')
    gui_parser.set_defaults(func=cmd_gui)

    # Config subcommand
    config_parser = subparsers.add_parser('config', help='Manage configuration and presets')
    config_parser.add_argument('--list', action='store_true', help='List current configurations')
    config_parser.add_argument('--create', help='Create new preset')
    config_parser.set_defaults(func=cmd_config)

    # Plugin subcommand
    plugin_parser = subparsers.add_parser('plugin', help='Manage plugins and extensions')
    plugin_parser.add_argument('--list', action='store_true', help='List installed plugins')
    plugin_parser.add_argument('--install', help='Install plugin from path or URL')
    plugin_parser.set_defaults(func=cmd_plugin)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Setup logging
    setup_logging(args.log)

    # Run the selected command
    return args.func(args)

if __name__ == '__main__':
    sys.exit(main())