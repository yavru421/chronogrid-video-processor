function Process-VideoFootage {
    param(
        [string]$InputDir = 'C:\Users\John\Downloads\Files2025-11-07_21-05-07',
        [switch]$AnalyzeChronogrid,
        [string]$Token,
        [int]$Workers,
        [switch]$Progress,
        [switch]$BatchMode
    )
    
    $scriptPath = 'C:\Users\John\Desktop\audio\process_footage.py'
    
    # Validate input directory
    if (-not (Test-Path $InputDir)) {
        Write-Error "Input directory does not exist: $InputDir"
        return
    }
    
    # Check for video files
    $videoFiles = Get-ChildItem $InputDir -Include '*.mov','*.mp4' -Recurse
    if ($videoFiles.Count -eq 0) {
        Write-Warning "No video files found in $InputDir"
        return
    }
    
    Write-Host "Found $($videoFiles.Count) video files to process" -ForegroundColor Green
    
    $args = @('--input-dir', $InputDir)
    
    if ($AnalyzeChronogrid) {
        $args += '--analyze-chronogrid'
    }
    
    if ($Token) {
        $args += '--token', $Token
    }
    
    if ($Workers -gt 0) {
        $args += '--workers', $Workers.ToString()
    }
    
    try {
        if ($Progress) {
            Write-Host "Starting video processing with progress tracking..." -ForegroundColor Yellow
        }
        
        & python $scriptPath @args
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Video processing completed successfully!" -ForegroundColor Green
            
            # Generate summary
            $outputDirs = Get-ChildItem $InputDir -Directory | Where-Object { $_.Name -match '^\w+' }
            Write-Host "Generated outputs in $($outputDirs.Count) directories:" -ForegroundColor Cyan
            foreach ($dir in $outputDirs) {
                $files = Get-ChildItem $dir.FullName -File
                Write-Host "  $($dir.Name): $($files.Count) files" -ForegroundColor Gray
            }
        } else {
            Write-Error "Video processing failed with exit code $LASTEXITCODE"
        }
    }
    catch {
        Write-Error "Error during video processing: $_"
    }
}

# Enhanced batch processing function
function Process-VideoBatch {
    param(
        [string[]]$Directories,
        [switch]$AnalyzeAll,
        [int]$MaxWorkers = 2
    )
    
    foreach ($dir in $Directories) {
        Write-Host "Processing directory: $dir" -ForegroundColor Yellow
        Process-VideoFootage -InputDir $dir -AnalyzeChronogrid:$AnalyzeAll -Workers $MaxWorkers -Progress
        Write-Host ""
    }
}
