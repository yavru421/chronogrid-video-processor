# Chronogrid Easy Processor
# Simple PowerShell script to process videos into chronogrids with AI analysis

param(
    [string]$VideoPath = "",
    [switch]$NoAI,
    [switch]$Help
)

if ($Help) {
    Write-Host "Chronogrid Easy Processor"
    Write-Host "Usage: .\process-video.ps1 -VideoPath 'path\to\video.mp4' [-NoAI]"
    Write-Host ""
    Write-Host "Parameters:"
    Write-Host "  -VideoPath: Path to the video file to process"
    Write-Host "  -NoAI: Skip AI analysis (optional)"
    Write-Host "  -Help: Show this help"
    exit
}

if (-not $VideoPath) {
    $VideoPath = Read-Host "Enter the path to the video file"
}

if (-not (Test-Path $VideoPath)) {
    Write-Host "Error: Video file not found at $VideoPath" -ForegroundColor Red
    exit 1
}

# Build the command - use safer approach
$videoPathEscaped = $VideoPath -replace '"', '""'  # Escape quotes for cmd
$cmd = "python chronogrid.py `"$videoPathEscaped`""
if ($NoAI) {
    $cmd += " --no-ai"
}

Write-Host "Running: $cmd" -ForegroundColor Green

# Run the command using call operator instead of Invoke-Expression for better security
& python chronogrid.py $VideoPath $(if ($NoAI) { "--no-ai" })

Write-Host "Processing complete! Check the outputs folder." -ForegroundColor Green