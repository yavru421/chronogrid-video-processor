param(
    [int]$Workers,
    [switch]$AnalyzeChronogrid,
    [string]$Token,
    [string]$InputDir,
    [switch]$Help
)

# Display help if requested
if ($Help) {
    Write-Host "Video Processing Pipeline"
    Write-Host "Usage: process-footage [options]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -Workers <int>          Number of parallel workers (auto-detected if not specified)"
    Write-Host "  -AnalyzeChronogrid      Analyze chronogrids with Llama Vision API"
    Write-Host "  -Token <string>         Bearer token for Llama API (optional if LLAMA_API_KEY environment variable is set)"
    Write-Host "  -InputDir <string>      Directory containing video files to process (defaults to current directory)"
    Write-Host "  -Help                   Show this help message"
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  process-footage"
    Write-Host "  process-footage -InputDir 'C:\Videos'"
    Write-Host "  process-footage -AnalyzeChronogrid -Workers 4"
    exit 0
}

# Get the script directory and construct Python script path
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonPath = Join-Path $scriptDir "process_footage.py"

# Check if Python script exists
if (!(Test-Path $pythonPath)) {
    Write-Error "Python script not found at: $pythonPath"
    exit 1
}

# Build Python arguments
$pythonArgs = @()

if ($PSBoundParameters.ContainsKey('Workers')) {
    $pythonArgs += "--workers", $Workers.ToString()
}

if ($AnalyzeChronogrid) {
    $pythonArgs += "--analyze-chronogrid"
}

if ($Token) {
    $pythonArgs += "--token", $Token
}

if ($InputDir) {
    $pythonArgs += "--input-dir", $InputDir
}

# Execute the Python script
Write-Host "Starting video processing pipeline..." -ForegroundColor Green
& python $pythonPath @pythonArgs

# Check exit code
if ($LASTEXITCODE -ne 0) {
    Write-Error "Video processing failed with exit code: $LASTEXITCODE"
    exit $LASTEXITCODE
}