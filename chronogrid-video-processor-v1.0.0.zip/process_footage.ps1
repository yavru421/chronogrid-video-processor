param(
    [int]$MaxWorkers = 0,
    [switch]$AnalyzeWithLlama,
    [string]$BearerToken,
    [switch]$TranscribeAudio,
    [string]$ModelSize = "base"
)

# Configure logging
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogMessage = "$Timestamp - $Level - $Message"
    Write-Host $LogMessage
}

# Detect hardware acceleration
function Get-HardwareAcceleration {
    $accelOptions = @()

    # Check for NVIDIA GPU
    try {
        $result = & nvidia-smi 2>$null
        if ($LASTEXITCODE -eq 0) {
            $accelOptions += "cuda"
            Write-Log "NVIDIA GPU detected - CUDA acceleration available"
        }
    } catch {
        # NVIDIA not available
    }

    # Check for Intel QuickSync
    try {
        $result = & ffmpeg -hide_banner -hwaccels 2>$null
        if ($result -match "qsv") {
            $accelOptions += "qsv"
            Write-Log "Intel QuickSync detected"
        }
    } catch {
        # ffmpeg not available
    }

    # Check for VAAPI
    try {
        $result = & ffmpeg -hide_banner -hwaccels 2>$null
        if ($result -match "vaapi") {
            $accelOptions += "vaapi"
            Write-Log "VAAPI detected"
        }
    } catch {
        # ffmpeg not available
    }

    return $accelOptions
}

# Get video metadata
function Get-VideoMetadata {
    param([string]$VideoPath)

    try {
        $result = & ffprobe -v quiet -print_format json -show_format -show_streams $VideoPath
        return $result | ConvertFrom-Json
    } catch {
        Write-Log "Failed to get metadata for $VideoPath`: $($_.Exception.Message)" "ERROR"
        return $null
    }
}

# Detect scenes
function Find-Scenes {
    param([string]$VideoPath, [string]$OutputDir, [array]$HwAccel)

    try {
        $sceneFile = Join-Path $OutputDir "scenes.txt"
        $ffmpegArgs = @("-hide_banner", "-i", $VideoPath, "-vf", "select=gt(scene\,0.3),metadata=print:file=$sceneFile", "-f", "null", "-")

        if ($HwAccel -contains "cuda") {
            $ffmpegArgs = @("-hwaccel", "cuda") + $ffmpegArgs
        }

        & ffmpeg $ffmpegArgs | Out-Null

        $scenes = @()
        if (Test-Path $sceneFile) {
            $content = Get-Content $sceneFile
            foreach ($line in $content) {
                if ($line -match "pts_time:") {
                    $timeStr = ($line -split "pts_time:")[1].Trim().Split()[0]
                    $scenes += [float]$timeStr
                }
            }
        }

        # Extract scene frames
        $sceneFrames = @()
        $sceneCount = [math]::Min(10, $scenes.Count)
        for ($i = 0; $i -lt $sceneCount; $i++) {
            $timestamp = $scenes[$i]
            $framePath = Join-Path $OutputDir ("scene_{0:00}_{1:.1f}s.jpg" -f ($i+1), $timestamp)

            $frameArgs = @("-hide_banner", "-loglevel", "warning", "-ss", $timestamp.ToString(), "-i", $VideoPath, "-vframes", "1", "-q:v", "2", "-y", $framePath)

            if ($HwAccel -contains "cuda") {
                $frameArgs = @("-hwaccel", "cuda", "-hwaccel_device", "0") + $frameArgs
            }

            & ffmpeg $frameArgs | Out-Null
            $sceneFrames += $framePath
        }

        return $scenes.Count, $sceneFrames
    } catch {
        Write-Log "Failed to detect scenes for $VideoPath`: $($_.Exception.Message)" "ERROR"
        return 0, @()
    }
}

# Generate chronogrid
function New-Chronogrid {
    param([string]$VideoPath, [string]$OutputPath, [array]$HwAccel)

    try {
        $metadata = Get-VideoMetadata $VideoPath
        $duration = if ($metadata -and $metadata.format.duration) { [float]$metadata.format.duration } else { 60.0 }

        $gridSize = 4
        $totalFrames = $gridSize * $gridSize

        # Exponential time spacing
        $timestamps = @()
        for ($i = 0; $i -lt $totalFrames; $i++) {
            $progress = [math]::Pow(($i / ($totalFrames - 1)), 0.7)
            $timestamp = $progress * $duration
            $timestamps += $timestamp
        }

        # Create temp directory
        $tempDir = Join-Path (Split-Path $OutputPath -Parent) "chrono_frames"
        if (!(Test-Path $tempDir)) { New-Item -ItemType Directory -Path $tempDir | Out-Null }

        $framePaths = @()
        for ($i = 0; $i -lt $timestamps.Count; $i++) {
            $ts = $timestamps[$i]
            $framePath = Join-Path $tempDir ("chrono_{0:00}.jpg" -f $i)

            $vfFilter = "scale=320:-1,drawtext=text='$($ts.ToString("0.0"))s':x=5:y=5:fontsize=12:fontcolor=white:box=1:boxcolor=black@0.5"
            $ffmpegArgs = @("-hide_banner", "-loglevel", "warning", "-ss", $ts.ToString(), "-i", $VideoPath, "-vframes", "1", "-vf", $vfFilter, "-q:v", "3", "-y", $framePath)

            if ($HwAccel -contains "cuda") {
                $ffmpegArgs = @("-hwaccel", "cuda") + $ffmpegArgs
            }

            & ffmpeg $ffmpegArgs | Out-Null
            $framePaths += $framePath
        }

        # Create montage
        try {
            $videoName = Split-Path $VideoPath -Leaf
            $montageArgs = $framePaths + @("-tile", "$gridSize`x$gridSize", "-geometry", "+1+1", "-pointsize", "10", "-title", "Chronogrid: $videoName ($($duration.ToString("0.0"))s)", $OutputPath)
            & montage $montageArgs | Out-Null
        } catch {
            # Fallback to ffmpeg tile
            $tileArgs = @("-hide_banner", "-loglevel", "warning") + $framePaths + @("-filter_complex", "tile=$gridSize`x$gridSize`:margin=2:padding=2", "-y", $OutputPath)
            & ffmpeg $tileArgs | Out-Null
        }

        # Cleanup
        if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }

        return $true
    } catch {
        Write-Log "Failed to generate chronogrid for $VideoPath`: $($_.Exception.Message)" "ERROR"
        return $false
    }
}

# Generate audio spectrogram
function New-AudioSpectrogram {
    param([string]$VideoPath, [string]$OutputPath, [array]$HwAccel)

    try {
        $ffmpegArgs = @("-hide_banner", "-loglevel", "warning", "-i", $VideoPath, "-vn", "-lavfi", "showspectrumpic=s=1024x512:legend=1", "-y", $OutputPath)
        & ffmpeg $ffmpegArgs | Out-Null
        return $true
    } catch {
        Write-Log "Failed to generate spectrogram for $VideoPath`: $($_.Exception.Message)" "ERROR"
        return $false
    }
}

# Stabilize video
function New-StabilizedVideo {
    param([string]$VideoPath, [string]$OutputPath, [array]$HwAccel)

    try {
        $outputDir = Split-Path $OutputPath -Parent

        # First pass: detect motion
        $detectArgs = @("-hide_banner", "-loglevel", "warning", "-i", $VideoPath, "-vf", "vidstabdetect=stepsize=6:shakiness=8:accuracy=9:result=transform.trf", "-f", "null", "-")
        if ($HwAccel -contains "cuda") {
            $detectArgs = @("-hwaccel", "cuda") + $detectArgs
        }
        & ffmpeg $detectArgs | Out-Null

        # Second pass: apply stabilization
        $stabilizeArgs = @("-hide_banner", "-loglevel", "warning", "-i", $VideoPath, "-vf", "vidstabtransform=input=transform.trf:zoom=5:smoothing=30", "-c:v", "libx264", "-preset", "fast", "-crf", "22", "-c:a", "copy", "-y", $OutputPath)
        if ($HwAccel -contains "cuda") {
            $stabilizeArgs[$stabilizeArgs.IndexOf("-c:v") + 1] = "h264_nvenc"
        }
        & ffmpeg $stabilizeArgs | Out-Null

        # Cleanup transform file
        $trfFile = Join-Path $outputDir "transform.trf"
        if (Test-Path $trfFile) { Remove-Item $trfFile -Force }

        return $true
    } catch {
        Write-Log "Failed to stabilize video $VideoPath`: $($_.Exception.Message)" "ERROR"
        return $false
    }
}

# Get optimal ffmpeg args
function Get-OptimalFfmpegArgs {
    param([string]$VideoPath, [string]$OutputType, [array]$HwAccel)

    $baseArgs = @("ffmpeg", "-hide_banner", "-loglevel", "warning")

    if ($HwAccel -contains "cuda") {
        $baseArgs += @("-hwaccel", "cuda", "-hwaccel_device", "0")
    } elseif ($HwAccel -contains "qsv") {
        $baseArgs += @("-hwaccel", "qsv")
    } elseif ($HwAccel -contains "vaapi") {
        $baseArgs += @("-hwaccel", "vaapi", "-hwaccel_device", "/dev/dri/renderD128")
    }

    $baseArgs += @("-i", $VideoPath)

    if ($OutputType -eq "frames") {
        $baseArgs += @("-q:v", "2", "-vf", "scale=-2:720", "-threads", "0")
        if ($HwAccel -contains "cuda") {
            $baseArgs += @("-c:v", "h264_nvenc")
        }
    } elseif ($OutputType -eq "audio") {
        $baseArgs += @("-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", "-af", "loudnorm", "-threads", "0")
    }

    return $baseArgs
}

# Get CPU count
function Get-CpuCount {
    $cpuCount = [Environment]::ProcessorCount
    $optimal = [math]::Max(1, [math]::Floor($cpuCount * 0.75))
    Write-Log "Detected $cpuCount CPU cores, using $optimal workers"
    return $optimal
}

# Check ffmpeg
function Test-Ffmpeg {
    try {
        & ffmpeg -version | Out-Null
        return $true
    } catch {
        Write-Log "ffmpeg not found. Please install ffmpeg." "ERROR"
        return $false
    }
}

# Process single video
function Start-VideoProcessing {
    param([string]$Video, [array]$HwAccel)

    try {
        $baseName = [IO.Path]::GetFileNameWithoutExtension($Video)
        $videoDir = $baseName
        if (!(Test-Path $videoDir)) { New-Item -ItemType Directory -Path $videoDir | Out-Null }

        # Extract metadata
        Write-Log "Extracting metadata from $Video..."
        $metadata = Get-VideoMetadata $Video
        $metadataPath = Join-Path $videoDir "$baseName`_metadata.json"
        if ($metadata) {
            $metadata | ConvertTo-Json -Depth 10 | Out-File $metadataPath -Encoding UTF8
        }

        # Detect scenes
        Write-Log "Detecting scenes in $Video..."
        $numScenes, $sceneFrames = Find-Scenes $Video $videoDir $HwAccel
        Write-Log "Detected $numScenes scenes"

        # Generate chronogrid
        Write-Log "Generating chronogrid for $Video..."
        $chronogridPath = Join-Path $videoDir "$baseName`_chronogrid.jpg"
        New-Chronogrid $Video $chronogridPath $HwAccel

        # Generate audio spectrogram
        Write-Log "Generating audio spectrogram for $Video..."
        $spectrogramPath = Join-Path $videoDir "$baseName`_spectrogram.png"
        New-AudioSpectrogram $Video $spectrogramPath $HwAccel

        # Stabilize video
        Write-Log "Stabilizing video $Video..."
        $stabilizedPath = Join-Path $videoDir "$baseName`_stabilized.mp4"
        New-StabilizedVideo $Video $stabilizedPath $HwAccel

        # Extract frames
        Write-Log "Extracting frames from $Video..."
        $frameOutput = Join-Path $videoDir "$baseName`_%04d.jpg"
        $frameArgs = Get-OptimalFfmpegArgs $Video "frames" $HwAccel
        $frameArgs += $frameOutput
        & ffmpeg $frameArgs | Out-Null

        # Extract audio
        Write-Log "Extracting audio from $Video..."
        $audioPath = Join-Path $videoDir "$baseName.wav"
        $audioArgs = Get-OptimalFfmpegArgs $Video "audio" $HwAccel
        $audioArgs += @("-y", $audioPath)
        & ffmpeg $audioArgs | Out-Null

        # Count frames and update metadata
        $frameCount = (Get-ChildItem (Join-Path $videoDir "$baseName`_*.jpg")).Count
        if ($metadata) {
            $metadata | Add-Member -MemberType NoteProperty -Name "processing" -Value @{
                frame_count = $frameCount
                scene_count = $numScenes
                scene_frames = ($sceneFrames | ForEach-Object { Split-Path $_ -Leaf })
            } -Force
            $metadata | ConvertTo-Json -Depth 10 | Out-File $metadataPath -Encoding UTF8
        }

        Write-Log "Completed processing $Video"
        return $true
    } catch {
        Write-Log "Error processing $Video`: $($_.Exception.Message)" "ERROR"
        return $false
    }
}

# Main processing function
function Invoke-FootageProcessing {
    param([int]$MaxWorkers = 0, [switch]$AnalyzeWithLlama, [string]$BearerToken)

    if (!(Test-Ffmpeg)) { return }

    # Detect hardware acceleration
    $hwAccel = Get-HardwareAcceleration

    # Auto-detect workers
    if ($MaxWorkers -eq 0) { $MaxWorkers = Get-CpuCount }

    # Find videos
    $videos = Get-ChildItem "*.MOV" -File
    if (!$videos) { $videos = Get-ChildItem "*.mp4" -File }
    if (!$videos) {
        Write-Log "No .mov or .mp4 files found in current directory"
        return
    }

    Write-Log "Found $($videos.Count) video files to process"
    Write-Log "Using $MaxWorkers workers with hardware acceleration: $($hwAccel -join ', ')"

    # Process videos (simplified - no parallel for PowerShell complexity)
    $successful = 0
    foreach ($video in $videos) {
        if (Start-VideoProcessing $video.FullName $hwAccel) { $successful++ }
    }

    Write-Log "Processed $successful/$($videos.Count) videos successfully"
}

# Run main function
Invoke-FootageProcessing -MaxWorkers $MaxWorkers -AnalyzeWithLlama:$AnalyzeWithLlama -BearerToken $BearerToken</content>
<parameter name="filePath">c:\Users\John\Desktop\audio\process_footage.ps1