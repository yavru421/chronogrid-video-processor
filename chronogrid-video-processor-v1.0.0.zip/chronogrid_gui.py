#!/usr/bin/env python3
"""
Chronogrid GUI - Graphical User Interface for Video Processing

A modern GUI for batch processing videos into chronogrids with AI analysis.
"""


import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import threading
import sys
from pathlib import Path

# Drag-and-drop support
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD  # type: ignore
except ImportError:
    DND_FILES = None  # type: ignore
    TkinterDnD = None  # type: ignore

# Markdown rendering support
try:
    from tkhtmlview import HTMLLabel  # type: ignore
except ImportError:
    HTMLLabel = None  # type: ignore

# Import existing modules
from process_footage import process_video, ensure_ffmpeg, iter_video_files

class ChronogridControlRoom:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Chronogrid GUI Suite - Visual Timeline Analysis")
        self.root.geometry("1200x800")

        # File list
        self.file_listbox = tk.Listbox(self.root, selectmode=tk.MULTIPLE, height=10)
        self.file_listbox.pack(fill=tk.X, padx=10, pady=5)

        # Buttons frame
        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill=tk.X, padx=10, pady=5)

        ttk.Button(button_frame, text="➕ Add Files", command=self.add_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="➖ Remove Selected", command=self.remove_selected).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🗑️ Clear All", command=self.clear_all).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🚀 Generate Chronogrids", command=self.generate_chronogrids).pack(side=tk.LEFT, padx=5)

        # Main content area with tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Preview tab
        preview_frame = ttk.Frame(self.notebook)
        self.notebook.add(preview_frame, text="Chronogrid Preview")
        self.preview_canvas = tk.Canvas(preview_frame, bg='gray', height=400)
        self.preview_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # AI Analysis tab
        analysis_frame = ttk.Frame(self.notebook)
        self.notebook.add(analysis_frame, text="AI Analysis")
        self.analysis_text = tk.Text(analysis_frame, wrap=tk.WORD, font=("Consolas", 10))
        analysis_scrollbar = ttk.Scrollbar(analysis_frame, command=self.analysis_text.yview)
        self.analysis_text.config(yscrollcommand=analysis_scrollbar.set)
        self.analysis_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        analysis_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Processing Log tab
        log_frame = ttk.Frame(self.notebook)
        self.notebook.add(log_frame, text="Processing Log")
        self.log_mode = tk.StringVar(value="terminal")
        toggle_frame = ttk.Frame(log_frame)
        toggle_frame.pack(fill=tk.X)
        ttk.Radiobutton(toggle_frame, text="Terminal", variable=self.log_mode, value="terminal", command=self.update_log_view).pack(side=tk.LEFT)
        ttk.Radiobutton(toggle_frame, text="Markdown", variable=self.log_mode, value="markdown", command=self.update_log_view).pack(side=tk.LEFT)

        self.log_text = tk.Text(log_frame, height=15, wrap=tk.WORD)
        self.log_text.pack(fill=tk.X)
        self.markdown_label = None
        if HTMLLabel:
            self.markdown_label = HTMLLabel(log_frame, html="", background="black", foreground="white")
            self.markdown_label.pack(fill=tk.X)
            self.markdown_label.pack_forget()

        # Progress bar
        self.progress = ttk.Progressbar(self.root, orient="horizontal", mode="determinate")
        self.progress.pack(fill=tk.X, padx=10, pady=5)

        # Status bar
        self.status_label = ttk.Label(self.root, text="Ready. Please add video files.")
        self.status_label.pack(fill=tk.X, padx=10, pady=5)

        # Sidebar for context
        self.sidebar_video_label = ttk.Label(self.root, text="Video: None")
        self.sidebar_video_label.pack(anchor=tk.W, padx=10)
        self.sidebar_folder_label = ttk.Label(self.root, text="Folder: None")
        self.sidebar_folder_label.pack(anchor=tk.W, padx=10)

        # Drag-and-drop setup (always last)
        if DND_FILES:
            self.root.drop_target_register(DND_FILES)
            self.root.dnd_bind('<<Drop>>', self.on_drop)
    def on_drop(self, event: object):
        paths = self.root.tk.splitlist(event.data)
        for path in paths:
            p = Path(path)
            if p.is_file():
                if p.suffix.lower() in {'.mp4', '.mov', '.m4v', '.jpg', '.jpeg', '.png'}:
                    self.file_listbox.insert(tk.END, str(p))
            elif p.is_dir():
                for file in p.rglob('*'):
                    if file.is_file() and file.suffix.lower() in {'.mp4', '.mov', '.m4v', '.jpg', '.jpeg', '.png'}:
                        self.file_listbox.insert(tk.END, str(file))

        # Update status
        self.status_label.config(text=f"Added {len(paths)} items. Ready to process.")

    def add_files(self):
        files = filedialog.askopenfilenames(filetypes=[("Video files", "*.mp4 *.mov *.m4v")])
        for file in files:
            self.file_listbox.insert(tk.END, file)

    def remove_selected(self):
        selected = self.file_listbox.curselection()
        for i in reversed(selected):
            self.file_listbox.delete(i)

    def clear_all(self):
        self.file_listbox.delete(0, tk.END)

    def log(self, message: str):
        self.log_text.insert(tk.END, message + '\n')
        self.log_text.see(tk.END)
        self.update_markdown_log()

    def update_markdown_log(self):
        if self.markdown_label:
            # Convert log text to markdown-like HTML
            log_content = self.log_text.get("1.0", tk.END)
            html = f"<pre style='color:white;background:black;font-family:monospace;'>{log_content}</pre>"
            self.markdown_label.set_html(html)

    def update_log_view(self):
        mode = self.log_mode.get()
        if mode == "terminal":
            self.log_text.pack(fill=tk.X)
            if self.markdown_label:
                self.markdown_label.pack_forget()
        elif mode == "markdown":
            self.log_text.pack_forget()
            if self.markdown_label:
                self.markdown_label.pack(fill=tk.X)

    def set_current_video(self, video_path):
        self.sidebar_video_label.config(text=f"Video: {Path(video_path).name}")

    def set_current_folder(self, folder_path):
        self.sidebar_folder_label.config(text=f"Folder: {folder_path}")

    def generate_chronogrids(self):
        selected = self.file_listbox.curselection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select video files to process.")
            return

        videos = [self.file_listbox.get(i) for i in selected]

        # Clear previous analysis
        self.analysis_text.delete(1.0, tk.END)
        self.analysis_text.insert(tk.END, "Processing videos... AI analysis will appear here.\n")

        # Run processing in a thread to avoid freezing GUI
        threading.Thread(target=self._process_videos, args=(videos,), daemon=True).start()

    def _process_videos(self, videos):
        self.progress['maximum'] = len(videos)
        self.progress['value'] = 0

        for video in videos:
            self.log(f"Processing {video}...")
            try:
                result = process_video(Path(video))
                self.log(f"✓ Completed {video}")

                # Display chronogrid image in preview tab
                if result.chronogrid_path.exists():
                    try:
                        from PIL import Image, ImageTk
                        img = Image.open(result.chronogrid_path)
                        img = img.resize((600, 400))
                        self.preview_img = ImageTk.PhotoImage(img)
                        self.preview_canvas.delete("all")
                        self.preview_canvas.create_image(300, 200, image=self.preview_img)
                        # Switch to preview tab
                        self.notebook.select(0)
                    except Exception as e:
                        self.log(f"✗ Failed to display chronogrid: {e}")

                # Display AI analysis in dedicated analysis tab
                if result.analysis_text:
                    self.analysis_text.delete(1.0, tk.END)
                    self.analysis_text.insert(tk.END, f"AI Analysis for: {Path(video).name}\n")
                    self.analysis_text.insert(tk.END, "=" * 50 + "\n\n")
                    self.analysis_text.insert(tk.END, result.analysis_text)
                    # Switch to analysis tab
                    self.notebook.select(1)
                    self.log("✓ AI Analysis loaded into Analysis tab")

            except Exception as e:
                self.log(f"✗ Failed {video}: {e}")
            self.progress['value'] += 1

        self.log("Processing complete.")
        messagebox.showinfo("Done", "Chronogrid generation completed with AI analysis!")

def main():
    # Use TkinterDnD for drag-and-drop if available
    if TkinterDnD:
        root = TkinterDnD.Tk()
    else:
        root = tk.Tk()
    app = ChronogridControlRoom(root)
    root.mainloop()

if __name__ == '__main__':
    main()