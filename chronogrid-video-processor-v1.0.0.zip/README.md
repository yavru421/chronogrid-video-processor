# Chronogrid Video Processor

An industry-ready CLI/GUI tool for generating chronogrids from videos and performing AI analysis.

## Features

- **Batch Video Processing**: Convert videos to chronological grid images
- **AI Analysis**: Use Llama Vision API for intelligent video content analysis
- **CLI Interface**: Command-line interface with comprehensive options
- **GUI Interface**: Modern Tkinter-based GUI with drag-and-drop support
- **REST API**: HTTP API for integration with other tools
- **Large Image Support**: Automatic quadrant splitting for high-resolution analysis
- **Cross-Platform**: Windows, macOS, and Linux support

## Installation

### Prerequisites
- Python 3.8 or higher
- FFmpeg (for video processing)
- Llama API key (for AI analysis)

### Install from Source

1. Clone the repository:
```bash
git clone https://github.com/yavru421/chronogrid-video-processor.git
cd chronogrid-video-processor
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up your Llama API key:
```bash
export LLAMA_API_KEY="your-api-key-here"
```

### Install FFmpeg

**Windows:**
- Download from https://ffmpeg.org/download.html
- Add to PATH

**macOS:**
```bash
brew install ffmpeg
```

**Linux:**
```bash
sudo apt install ffmpeg
```

## Usage

### CLI

Process a single video:
```bash
python chronogrid.py video.mp4
```

Process with custom options:
```bash
python chronogrid.py video.mp4 --frame-step 15 --grid-size 5
```

Skip AI analysis:
```bash
python chronogrid.py video.mp4 --no-ai
```

### GUI

Launch the graphical interface:
```bash
python chronogrid_gui.py
```

Features:
- Drag and drop videos/folders
- Real-time progress tracking
- Built-in chronogrid preview
- Dedicated AI analysis viewer
- Batch processing support

### PowerShell Script (Windows)

For easy video processing:
```powershell
.\process-video.ps1
```

### REST API

Start the API server:
```bash
python chronogrid_api.py
```

Submit a job:
```bash
curl -X POST http://localhost:5000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -d '{"video_path": "video.mp4"}'
```

## Output Structure

For input `video.mp4`, creates `outputs/video/` directory with:
- `video_chronogrid.jpg`: Chronological grid image
- `video_chronogrid_analysis.txt`: AI analysis results
- `video_chronogrid_analysis.json`: Structured analysis data

## Configuration

### Environment Variables
- `LLAMA_API_KEY`: Your Llama API key (required for AI analysis)

### Analysis Prompts
Customize AI analysis prompts in the code or via command line options.

## Development

### Running Tests
```bash
pytest tests/
```

### Code Quality
```bash
# Format code
black .

# Lint code
flake8 .
```

## Requirements

- Python 3.8+
- FFmpeg
- Llama API key (for analysis)
- Optional: tkinterdnd2, tkhtmlview (for enhanced GUI)

## License

MIT License - see LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## Support

For issues and questions:
- Open an issue on GitHub
- Check the troubleshooting section in the wiki

### API

Start the API server:
```bash
python chronogrid_api.py
```

Submit a job:
```bash
curl -X POST http://localhost:5000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -d '{"video_path": "video.mp4"}'
```

## Configuration

Create a `config.yaml` file for presets:

```yaml
presets:
  high_quality:
    frame_step: 15
    grid_size: 4
    analyze: true
    prompt: "Custom analysis prompt"
```

## Plugins

Plugins are Python modules in the `plugins/` directory. Implement the plugin interface for custom functionality.

## Output

For input `video.mp4`, creates `video/` directory with:
- `video_chronogrid.jpg`: 4x4 grid image
- `video_metadata.json`: FFmpeg metadata
- `video_chronogrid_analysis.txt`: AI analysis results
- Individual frame images and other optional outputs

## Requirements

- Python 3.8+
- FFmpeg
- Llama API key (for analysis)

## License

See LICENSE file for details.